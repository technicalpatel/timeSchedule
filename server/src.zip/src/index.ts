import express from 'express'
import * as bodyParser from 'body-parser'
import Routers from './router/Routers'

const app=express()
app.use(bodyParser.json())

let routes=new Routers();
app.use('/v1',routes.path());

app.listen(3000,function(){
  console.log(`SERVER IS RUNNING ON PORT NUMBER 3000`)
})
