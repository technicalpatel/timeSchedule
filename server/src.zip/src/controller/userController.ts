import { Request,Response } from 'express';
class UserController{

  constructor(){
  }

  public userRegister = (req:Request,res:Response) =>{
    res.send("YOU CALLED USER CONTROLLER")
  }

}

export default UserController
